﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPA_FINANZAS_TESTING_SOL_SERVICIO
{
    public class FinanzaTesting
    {
        public string Codigo_SS { get; set; }
        public string HorasAnalisis { get; set; }
        public string HorasPruebas { get; set; }
        public string TK { get; set; }
        public string Aplicativo { get; set; }
        public Nullable<int> Criticidad { get; set; }

        public override string ToString()
        {


            return Codigo_SS.ToString() + "_" + HorasAnalisis + "_" + HorasPruebas;
        }

    }
}
