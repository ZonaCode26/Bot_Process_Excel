﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using System.Globalization;//Para obtener el mes en texto

using Excel = Microsoft.Office.Interop.Excel; // Para tratar el Excel
using System.IO;

using System.Configuration;
//Logs 
using System.Diagnostics;
using System.Data.SqlClient;

using System.Reflection;
using log4net;
using log4net.Config;


namespace RPA_CARGAR_HOJACONTROL
{
    static class Program
    {
        private static readonly ILog _log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public static string cs_Job = ConfigurationManager.ConnectionStrings["csTCS_AM"].ConnectionString;
        public static string cs_Remedy = ConfigurationManager.ConnectionStrings["csTCS_AM_Remedy"].ConnectionString;

        private static string RUTA_HOJACONTROL_FINAL = "";//@"\\pconsiisd05\Repositorio Administrador INDRA\CM\HojaControl\HojaControlFinal";
        private static string RUTA_DESCARGA_HOJACONTROL = "";//@"\\pconsiisd05\Repositorio Administrador INDRA\CM\HojaControl\HojaControlOrigen";

        private static string URL_BASE_HOJACONTROL = "";//"http://bcppoint/gcmin/dsyo/GST/GSE/TCS/Informacin%20Interfaz%20GSE%20%20TATA/01.%20Seguimiento%20Semanal/1.%20Hoja%20de%20Control/";

      //  private const string rutaOrigen = @"\\pconsiisd05\SSIS\ROBOTs Proyecto Automation Team\SELENIUM\HojaControl\HojaControlOrigen\";


        private static string siteBCP2 = "";
        private static string filename = "";//"Hoja de Control TCS 2019-II 19-04-22.xlsx";
        private static string newName = "HOJACONTROL";
                               
      //  private const string siteBCP = "http:// bcppoint/gcmin/dsyo/GST/GSE/TCS/default.aspx";
       // private const string siteBCPs = "http:// bcppoint/gcmin/dsyo/GST/GSE/TCS/Informacin%20Interfaz%20GSE%20%20TATA/01.%20Seguimiento%20Semanal/1.%20Hoja%20de%20Control";

        private static ChromeDriver driver = null;
       

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            /*
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());*/

            XmlConfigurator.Configure();
            _log.Info(new { Body = "Inició Programa" });


            try
            {
                cargarVariables();
                DescargarExcel();
                Thread.Sleep(2000);
                ProcesarExcel();
                
                _log.Info(new { Body = "Finalizó Programa" });

            }
            catch (Exception e)
            {
                if (driver != null)
                {
                    driver.Quit();
                }
                _log.Error(new { Body = "" + e.Message.ToString() });
                _log.Info(new { Body = "Finalizó Programa" });

            }

        }
        
        public static void cargarVariables()
        {
            _log.Info(new { Body = "Cargar Variables" });
            try
            {
                using (SqlConnection cn = new SqlConnection(Program.cs_Remedy))
                {
                    cn.Open();

                    RUTA_HOJACONTROL_FINAL = new SqlCommand("select ValorParametro from Parametros where NombreParametro='RUTA_HOJACONTROL_FINAL' ", cn).ExecuteScalar().ToString();
                    RUTA_DESCARGA_HOJACONTROL = new SqlCommand("SELECT ValorParametro FROM Parametros WHERE NombreParametro = 'RUTA_DESCARGA_HOJACONTROL' ", cn).ExecuteScalar().ToString();

                    URL_BASE_HOJACONTROL = new SqlCommand("select ValorParametro from Parametros where NombreParametro='URL_BASE_HOJACONTROL' ", cn).ExecuteScalar().ToString();
                  
                    cn.Close();
                }

                _log.Info(new { Body = "Finalizó Carga de  Variables" });
            }
            catch (Exception ex)
            {
                _log.Error(new { Body = "Error al Cargar Variables. " + ex.Message.ToString() });
                _log.Info(new { Body = "Finalizó Programa" });
                //Mostrar Error
                System.Console.WriteLine(ex.Message);
                //Program.saveLog(ex.ToString());
            }

        }
        public static void DescargarExcel()
        {

            _log.Info(new { Body = "Iniciando Descarga de Excel" });

            ChromeOptions chromeOptions = new ChromeOptions();
//            chromeOptions.AddUserProfilePreference("download.default_directory", @"\\pconsiisd05\SSIS\ROBOTs Proyecto Automation Team\SELENIUM\HojaControl\HojaControlOrigen");
            chromeOptions.AddUserProfilePreference("download.default_directory", RUTA_DESCARGA_HOJACONTROL);
            chromeOptions.AddUserProfilePreference("disable-popup-blocking", "true");
            //var driver = new ChromeDriver(@"\\PMDCSQL2K8CLD01\Shared\", chromeOptions);

            chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
            driver = new ChromeDriver(chromeOptions);
            Program.ObtenerRealUrlReporte();
            driver.Url = siteBCP2;
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Thread.Sleep(5000);

            driver.Quit();
            _log.Info(new { Body = "Finalizo Descarga de Excel" });

        }


        public static void ProcesarExcel()
        {

            // (oSheet.Rows[2]).Delete();

            if (File.Exists(Path.Combine(Program.RUTA_DESCARGA_HOJACONTROL, filename)))
            {
                _log.Info(new { Body = " Procesando Excel" });

                if (File.Exists(Path.Combine(Program.RUTA_HOJACONTROL_FINAL, newName + ".xls")))
                {
                    File.Delete(Path.Combine(Program.RUTA_HOJACONTROL_FINAL, newName + ".xls"));
                }


                // trata el excel descargado

                Microsoft.Office.Interop.Excel.Application ExApp;
                ExApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook oWBook;
                Microsoft.Office.Interop.Excel._Worksheet oSheet;

//                oWBook = ExApp.Workbooks.Open(rutaOrigen + filename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                oWBook = ExApp.Workbooks.Open(RUTA_DESCARGA_HOJACONTROL+"\\" + filename, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                oSheet = (Microsoft.Office.Interop.Excel._Worksheet)oWBook.ActiveSheet;

              

                (oSheet.Rows[1]).Delete();
                (oSheet.Rows[1]).Delete();



                ////////((Microsoft.Office.Interop.Excel.Range)oSheet.Range["O1", "UF1"]).EntireColumn.Delete(null);

                //((Microsoft.Office.Interop.Excel.Range)oSheet.Range["W1", "AD1"]).EntireColumn.Delete(null);
                //////((Microsoft.Office.Interop.Excel.Range)oSheet.Range["AZ1", "AZ1"]).EntireColumn.Delete(null);
                ((Microsoft.Office.Interop.Excel.Range)oSheet.Range["BB1", "IN1"]).EntireColumn.Delete(null);
                //////((Microsoft.Office.Interop.Excel.Range)oSheet.Range["IQ1", "IQ1"]).EntireColumn.Delete(null);
                //((Microsoft.Office.Interop.Excel.Range)oSheet.Range["IU1", "IW1"]).EntireColumn.Delete(null);
                //((Microsoft.Office.Interop.Excel.Range)oSheet.Range["JC1", "JQ1"]).EntireColumn.Delete(null);
                //((Microsoft.Office.Interop.Excel.Range)oSheet.Range["KB1", "KC1"]).EntireColumn.Delete(null);

                ((Microsoft.Office.Interop.Excel.Range)oSheet.Range["KG1", "UF1"]).EntireColumn.Delete(null);

                // oWBook.SaveAs(@"\\pconsiisd05\SSIS\ROBOTs Proyecto Automation Team\SELENIUM\HojaControl\HojaControlFinal\" + newName + ".xlsx");
                //oWBook.SaveAs(RUTA_HOJACONTROL_FINAL + "\\" + newName + ".xlsx");
                //oWBook.CheckCompatibility = false;
                //oWBook.DoNotPromptForConvert=true;


                //xlWorkbookNormal -> cOLUMNAS LIMIUTADAS
                //xlOpenXMLWorkbook-->TODAS LAS COLUMNAS MAXIMAS

                ExApp.Visible = false;
                ExApp.DisplayAlerts = false;
                oWBook.SaveAs(RUTA_HOJACONTROL_FINAL + "\\" + newName + ".xls", Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                ExApp.Visible = false;
                ExApp.UserControl = true;
                // ExApp.ActiveWorkbook.Close(true, rutaOrigen + filename, Type.Missing);
                ExApp.ActiveWorkbook.Close(true, RUTA_DESCARGA_HOJACONTROL + "\\" + filename, Type.Missing);
             
                // CambiardeFormato();
                ExApp.Quit();
                ExApp = null;


                File.Delete(Path.Combine(Program.RUTA_DESCARGA_HOJACONTROL, filename));
            }
            else {
                _log.Info(new { Body = "No existe Excel" });
            }
            Thread.Sleep(1000);
        }

        public static void ObtenerRealUrlReporte()
        {
            //DateTime fechaOrigen = Convert.ToDateTime("07/01/2019");
            DateTime fechaOrigen = DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd"));// Convert.ToDateTime("16/04/2010");

            string fecha = (DateTime.Now.ToString("yyyyMMdd"));
            //string fecha = Convert.ToDateTime("07/01/2019").ToString("yyyyMMdd");
            string aa = fecha.Substring(0, 4).Trim();
            string mm = fecha.Substring(4, 2).Trim();
            string dd = fecha.Substring(6, 2).Trim();
            string mesTexto = "Enero";
            string ciclo = "I";
            string mesnumerosincero = "1";
            string url = "";
            string aaDosCifras = aa.Substring(2, 2);

            DateTimeFormatInfo dtinfo = new CultureInfo("es-ES", false).DateTimeFormat;
            //Hoja de Control TCS 2018-I 18-03-26.xlsx

            mesTexto = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(dtinfo.GetMonthName(fechaOrigen.Month));

            if (int.Parse(mm) <= 3)
            {
                ciclo = "I";
                mesnumerosincero = int.Parse(mm).ToString();
            }
            if (int.Parse(mm) >= 4 && int.Parse(mm) <= 6)
            {
                ciclo = "II";
                mesnumerosincero = int.Parse(mm).ToString();
            }

            if (int.Parse(mm) >= 7 && int.Parse(mm) <= 9)
            {
                ciclo = "III";
                mesnumerosincero = int.Parse(mm).ToString();
            }
            if (int.Parse(mm) >= 10 && int.Parse(mm) <= 12)
            {
                ciclo = "IV";
                mesnumerosincero = int.Parse(mm).ToString();
            }

            //Hoja de Control TCS 2018-I 18-03-26.xlsx
            filename = "Hoja de Control TCS " + aa + "-" + ciclo + " " + aaDosCifras + "-" + mm + "-" + dd + ".xlsx";
            //            url = "http: //bcppoint/gcmin/dsyo/GST/GSE/TCS/Informacin%20Interfaz%20GSE%20%20TATA/01.%20Seguimiento%20Semanal/1.%20Hoja%20de%20Control/" + aa + "/" + aa + "-" + ciclo + "/" + mesnumerosincero + ".%20" + mesTexto + "/Hoja%20de%20Control%20TCS%20" + aa + "-" + ciclo + "%" + aa + "-" + mm + "-" + dd + ".xlsx";
            url = URL_BASE_HOJACONTROL + aa + "/" + aa + "-" + ciclo + "/" + mesnumerosincero + ".%20" + mesTexto + "/Hoja%20de%20Control%20TCS%20" + aa + "-" + ciclo + "%" + aa + "-" + mm + "-" + dd + ".xlsx";

            siteBCP2 = url;
        }


       


    }
}
