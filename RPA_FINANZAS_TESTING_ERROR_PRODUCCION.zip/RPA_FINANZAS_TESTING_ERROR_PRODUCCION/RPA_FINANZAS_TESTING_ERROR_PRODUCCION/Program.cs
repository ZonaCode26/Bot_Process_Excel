﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using Excel = Microsoft.Office.Interop.Excel; // Para tratar el Excel
using System.IO;


using System.Configuration;
using System.Diagnostics;
using System.Reflection;

using System.Data;
using System.Data.SqlClient;


namespace RPA_FINANZAS_TESTING_ERROR_PRODUCCION
{
    static class Program
    {


        private static string RUTA_MACROS = "";
        private static List<FinanzaTesting> ListaFinanza;        
        public static string cs_Remedy = ConfigurationManager.ConnectionStrings["csTCS_AM_Remedy"].ConnectionString;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Console.WriteLine("************************");
            ListaFinanza = new List<FinanzaTesting>();
            //ProcesarMacro();

            CargarRuta();

            ObtenerTodosLosArchivos();

           

            using (SqlConnection cn = new SqlConnection(Program.cs_Remedy))
            {
                foreach (var item in ListaFinanza)
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT  top 1  Codigo FROM Testing_Datos WHERE TK = @TK ", cn);
                    cmd.Parameters.AddWithValue("@TK", item.Codigo_TK.ToString());
                    //////cmd.Parameters.Add("@tk", SqlDbType.VarChar);
                    //////cmd.Parameters["@tk"].Value = item.Codigo_TK.ToString();
                    
                    bool flag = false;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            flag = true;
                        }
                    }

                    if (flag)
                    {
                        //update
                        SqlCommand cmd1 = new SqlCommand("UPDATE Testing_Datos SET  HorasAnalisis = @HorasAnalisis,HorasPruebas = @HorasPruebas,IdTipo = 1,Aplicativo=@Aplicativo, Criticidad =@Criticidad WHERE  TK =@TK ", cn);
                        cmd1.Parameters.AddWithValue("@TK", "" + item.Codigo_TK);
                        cmd1.Parameters.AddWithValue("@HorasAnalisis", "" + item.HorasAnalisis);
                        cmd1.Parameters.AddWithValue("@HorasPruebas", "" + item.HorasPruebas);
                        cmd1.Parameters.AddWithValue("@Aplicativo", "" + item.Aplicativo);
                        cmd1.Parameters.AddWithValue("@Criticidad", item.Criticidad);

                        
                        cmd1.ExecuteNonQuery();
                    } else {
                        //insert
                        SqlCommand cmd1 = new SqlCommand("INSERT INTO Testing_Datos(HorasAnalisis,HorasPruebas,IdTipo,TK,Aplicativo,Criticidad) VALUES(@HorasAnalisis,@HorasPruebas,1,@TK,@Aplicativo,@Criticidad)", cn);
                        cmd1.Parameters.AddWithValue("@TK", "" + item.Codigo_TK);
                        cmd1.Parameters.AddWithValue("@HorasAnalisis", "" + item.HorasAnalisis);
                        cmd1.Parameters.AddWithValue("@HorasPruebas", "" + item.HorasPruebas);
                        cmd1.Parameters.AddWithValue("@Aplicativo", "" + item.Aplicativo);
                        cmd1.Parameters.AddWithValue("@Criticidad", item.Criticidad);

                        cmd1.ExecuteNonQuery();
                    }

                  
                    Console.WriteLine(item);
                    cn.Close();
                }
            }

            Console.WriteLine("************************");

            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());
        }



        public static void CargarRuta() {
            using (SqlConnection cn = new SqlConnection(Program.cs_Remedy))
            {
                cn.Open();
                 SqlCommand cmd = new SqlCommand("select ValorParametro from Parametros where NombreParametro = 'RUTA_MACRO_ERRORPRODUCCION'", cn);

                RUTA_MACROS = cmd.ExecuteScalar().ToString();
                cn.Close();

            }
        }
        public static void ObtenerTodosLosArchivos() {
            //RUTA_MACROS = @"\\pfilep07\TCS\Automation Team\Web Financiera\Testing\Estimaciones_ErrorProduccion";
            DirectoryInfo di = new DirectoryInfo(RUTA_MACROS);
            Console.WriteLine("No search pattern returns:");
            int con = 0;
            foreach (var fi in di.GetFiles("*.xlsm"))
            {
                if (!fi.Name.Contains("~$"))
                {
                    con++;
                    ProcesarMacro(fi.Name);
                }               
            }
            Console.WriteLine("********"+con+"********");       
        }

        public static void ProcesarMacro(string filename)
        {
            if (File.Exists(Path.Combine(Program.RUTA_MACROS, filename)))
            {
                Microsoft.Office.Interop.Excel.Application excel;
                excel = new Microsoft.Office.Interop.Excel.Application();
                excel.Visible = true;
                //string fileName = "TCS_ SS000101648-SAT_SOLSERV.xlsm";
                string pathToExcelXlsmFile = Path.Combine(RUTA_MACROS, filename);
                Excel.Workbook wb;
                Excel.Worksheet ws;
                int sheetNumber = 1;
                wb = excel.Workbooks.Open(pathToExcelXlsmFile, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                ws = wb.Worksheets[sheetNumber];

                FinanzaTesting entidad = new FinanzaTesting();
                    entidad.Codigo_TK       = ws.Cells[9, 4].Value + "";
                    entidad.Criticidad =( ws.Cells[8, 4].Value==null || (ws.Cells[8, 4].Value+"")=="") ?0:int.Parse(ws.Cells[8, 4].Value+"");
                    entidad.HorasAnalisis   = ws.Cells[17, 11].Value + "";
                    entidad.HorasPruebas    = ws.Cells[23, 11].Value + "";
                    entidad.Aplicativo = ws.Cells[11, 4].Value + "";

                ListaFinanza.Add(entidad);
                Console.WriteLine(entidad.ToString());
                excel.Visible = false;
                excel.DisplayAlerts = false;
                excel.Visible = false;
                excel.UserControl = true;
                ws = null;

                excel.Quit();
                excel = null;
            }

        }


    }
}
