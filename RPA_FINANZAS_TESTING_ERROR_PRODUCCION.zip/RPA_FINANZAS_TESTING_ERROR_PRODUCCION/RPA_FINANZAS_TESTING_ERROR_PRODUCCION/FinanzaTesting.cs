﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPA_FINANZAS_TESTING_ERROR_PRODUCCION
{
    public class FinanzaTesting
    {

        public string Codigo_TK { get; set; }
        public string HorasAnalisis { get; set; }
        public string HorasPruebas { get; set; }
        public string TK { get; set; }
        public string Aplicativo { get; set; }
        public Nullable<int> Criticidad { get; set; }
        public override string ToString()
        {


            return Codigo_TK.ToString() +"_"+HorasAnalisis + "_" +HorasPruebas;
        }
    }
}
