﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPA_FINANZAS_CARGAR_REQUERIMIENTOS
{
    public class Requerimiento
    {
        public int IdRequerimiento { get; set; }
        public string SN { get; set; }
        public string ST { get; set; }
        public string FI_PLANIFICADA { get; set; }
        public string FF_PLANIFICADA { get; set; }
        public string TIPO_CONSTRUCCION { get; set; }
        public string APLICATIVO { get; set; }
        public string ESTADO { get; set; }
        public string PROVEDOR { get; set; }
        public string HORAS { get; set; }
        public string INDICADOR_GSE { get; set; }

    }
}
