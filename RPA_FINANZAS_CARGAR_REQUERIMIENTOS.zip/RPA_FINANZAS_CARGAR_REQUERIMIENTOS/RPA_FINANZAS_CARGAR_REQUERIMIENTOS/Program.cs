﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;




using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

using System.Globalization;//Para obtener el mes en texto
//Logs 
using System.Configuration;
    
using System.Reflection;

using System.Data;
using System.Web;
using System.IO;
using System.Data.SqlClient;



namespace RPA_FINANZAS_CARGAR_REQUERIMIENTOS
{
    static class Program
    {
        public static string cs_Remedy = ConfigurationManager.ConnectionStrings["csTCS_AM_Remedy"].ConnectionString;


        public static ChromeDriver driver;
        //  public static ChromeDriver driverII;
        private static ChromeOptions chromeOptions = new ChromeOptions();
        private static String parentWindowHandle = "";//web padre

        private static List<Requerimiento> listaRequerimiento;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            listaRequerimiento = new List<Requerimiento>();
            Acceder_qtctsqlc01();
            Agregar_ListaRequerimiento();
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());
        }


        public static void Agregar_ListaRequerimiento()
        {
            using (SqlConnection cn = new SqlConnection(Program.cs_Remedy))
            {
                cn.Open();


               


                foreach (var item in listaRequerimiento)
                {

                    SqlCommand cmd = new SqlCommand("SELECT  top 1  SN FROM Lista_Requerimiento WHERE SN = @SN AND ST =@ST ", cn);
                    cmd.Parameters.AddWithValue("@SN", item.SN.ToString());
                    cmd.Parameters.AddWithValue("@ST", item.ST.ToString());

                    bool flag = false;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            flag = true;
                        }
                    }

                    if (flag)
                    {
                        //update
                        SqlCommand cmd1 = new SqlCommand("UPDATE Lista_Requerimiento SET FI_PLANIFICADA=@FI_PLANIFICADA ,FF_PLANIFICADA= @FF_PLANIFICADA, TIPO_CONSTRUCCION=@TIPO_CONSTRUCCION, APLICATIVO=@APLICATIVO, ESTADO=@ESTADO, PROVEDOR=@PROVEDOR ,HORAS=@HORAS, INDICADOR_GSE= @INDICADOR_GSE WHERE SN = @SN AND ST = @ST", cn);
                        cmd1.Parameters.AddWithValue("@SN", "" + item.SN);
                        cmd1.Parameters.AddWithValue("@ST", "" + item.ST);
                        cmd1.Parameters.AddWithValue("@FI_PLANIFICADA", "" + item.FI_PLANIFICADA);
                        cmd1.Parameters.AddWithValue("@FF_PLANIFICADA", "" + item.FF_PLANIFICADA);
                        cmd1.Parameters.AddWithValue("@TIPO_CONSTRUCCION", "" + item.TIPO_CONSTRUCCION);
                        cmd1.Parameters.AddWithValue("@APLICATIVO", "" + item.APLICATIVO);
                        cmd1.Parameters.AddWithValue("@ESTADO", "" + item.ESTADO);
                        cmd1.Parameters.AddWithValue("@PROVEDOR", "" + item.PROVEDOR);
                        cmd1.Parameters.AddWithValue("@HORAS", "" + item.HORAS);
                        cmd1.Parameters.AddWithValue("@INDICADOR_GSE", "" + item.INDICADOR_GSE);

                        cmd1.ExecuteNonQuery();
                    }
                    else
                    {
                        //insert
                        SqlCommand cmd1 = new SqlCommand("INSERT INTO Lista_Requerimiento(SN,ST,FI_PLANIFICADA,FF_PLANIFICADA,TIPO_CONSTRUCCION,APLICATIVO,ESTADO,PROVEDOR,HORAS,INDICADOR_GSE) VALUES(@SN,@ST,@FI_PLANIFICADA,@FF_PLANIFICADA,@TIPO_CONSTRUCCION,@APLICATIVO,@ESTADO,@PROVEDOR,@HORAS,@INDICADOR_GSE)", cn);
                        cmd1.Parameters.AddWithValue("@SN", "" + item.SN);
                        cmd1.Parameters.AddWithValue("@ST", "" + item.ST);
                        cmd1.Parameters.AddWithValue("@FI_PLANIFICADA", "" + item.FI_PLANIFICADA);
                        cmd1.Parameters.AddWithValue("@FF_PLANIFICADA", "" + item.FF_PLANIFICADA);
                        cmd1.Parameters.AddWithValue("@TIPO_CONSTRUCCION", "" + item.TIPO_CONSTRUCCION);
                        cmd1.Parameters.AddWithValue("@APLICATIVO", "" + item.APLICATIVO);
                        cmd1.Parameters.AddWithValue("@ESTADO", "" + item.ESTADO);
                        cmd1.Parameters.AddWithValue("@PROVEDOR", "" + item.PROVEDOR);
                        cmd1.Parameters.AddWithValue("@HORAS", "" + item.HORAS);
                        cmd1.Parameters.AddWithValue("@INDICADOR_GSE", "" + item.INDICADOR_GSE);

                        cmd1.ExecuteNonQuery();
                    }

                  


                }
              

                cn.Close();

            }
        }
        public static void Acceder_qtctsqlc01()
        {

            string sURL;

            chromeOptions.AddUserProfilePreference("download.default_directory", @"\\pconsiisd05\SSIS\ROBOTs Proyecto Automation Team\SELENIUM\HojaControl\HojaControlOrigen");
            chromeOptions.AddUserProfilePreference("disable-popup-blocking", "true");
            chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
            driver = new ChromeDriver(chromeOptions);
            sURL = "http://qtctsqlc01:8888/hav/login.php";
            driver.Navigate().GoToUrl(sURL);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);


            if (driver.FindElementByName("matricula") != null)
            {

                driver.FindElementByName("matricula").SendKeys("S73659");
                driver.FindElementByName("clave").SendKeys("S73659");

                Thread.Sleep(2000);

                driver.FindElement(By.XPath("/html/body/div/form/table/tbody/tr[3]/td/button")).Click();

                Thread.Sleep(1000);
                driver.FindElement(By.LinkText("SN/ST")).Click();

                System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> rows = driver.FindElements(By.XPath("/html/body/div/table/tbody/tr"));

                int contTable = rows.Count();

                for (int i = 1; i <= contTable; i++)
                {
                    Requerimiento entity = new Requerimiento();

                    String SN = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[1]")).Text;
                    String ST = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[2]")).Text;
                    String FI_Planificada = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[3]")).Text;
                    String FF_Planificada = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[4]")).Text;
                    String Tipo_Construcción = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[5]")).Text;
                    String Aplicativo = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[6]")).Text;
                    String Estado = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[7]")).Text;
                    String Proveedor = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[8]")).Text;
                    String Horas = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[9]")).Text;
                    String Indicador_GSE = "";

                    String ValidarImagen = driver.FindElement(By.XPath("/html/body/div/table/tbody/tr[" + i + "]/td[10]/img")).GetAttribute("src");

                    if (ValidarImagen.Contains("check"))
                    {
                        Indicador_GSE = "OK";
                    }
                    else
                    {
                        Indicador_GSE = "NO";
                    }


                    entity.SN = SN;
                    entity.ST = ST;
                    entity.FI_PLANIFICADA = FI_Planificada;
                    entity.FF_PLANIFICADA = FF_Planificada;
                    entity.TIPO_CONSTRUCCION = Tipo_Construcción;
                    entity.APLICATIVO = Aplicativo;
                    entity.ESTADO = Estado;
                    entity.PROVEDOR = Proveedor;
                    entity.HORAS = Horas;
                    entity.INDICADOR_GSE = Indicador_GSE;
                  

                    listaRequerimiento.Add(entity);

                    Console.WriteLine(SN + " - " + ST + " - " + FI_Planificada + " - " + FF_Planificada + " - " + Tipo_Construcción + " - " + Aplicativo + " - " + Estado + " - " + Proveedor + " - " + Horas + " - " + Indicador_GSE + " - " + "\n");
                }

                //foreach (IWebElement item in rows)
                //{
                //    System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> ths = item.FindElements(By.TagName("th"));

                //    foreach (var thEnti in ths)
                //    {
                //        Console.Write(thEnti.Text);
                //    }

                //}
                driver.Quit();
            }
        }



    }
}
